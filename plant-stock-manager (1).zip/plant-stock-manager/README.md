# Green Corner – Plant Stock Manager

This project is built using React.js to manage the stock of a plant nursery. It includes features such as adding plants, removing plants, searching, filtering by place and category, and sorting by name and price. The UI uses a light cream and green theme with a left form panel and a card grid.

## Languages and Technologies Used

- React.js
- Vite
- JavaScript
- HTML
- CSS

## Features

- Add a plant (Plant ID, name, supplier email, place, price, category) with validation
- Duplicate Plant ID check
- Remove a plant with a confirmation popup
- Search across ID, name, email, place, price and category
- Filter by place (Indoor / Outdoor)
- Filter by category
- Sort by name (A to Z / Z to A)
- Sort by price (Low to High / High to Low)
- Applied-filter chips and a "Clear all" button
- Empty state and no-result state
- Live stats: total plants, total list value, number of categories
- Responsive layout for mobile

## How to Run

```bash
npm install
npm run dev
```

Build for production:

```bash
npm run build
```

## Project Structure

```
plant-stock-manager/
├── public/leaf.svg
├── screenshots/
├── src/
│   ├── App.jsx      # all logic and UI
│   ├── App.css      # styling
│   ├── data.js      # categories, places and starting plant data
│   ├── index.css
│   └── main.jsx
├── index.html
├── package.json
└── vite.config.js
```

## Screenshots

### Home

![Home](screenshots/home.png)

### Add Plant

![Add Plant](screenshots/add-plant.png)

### Duplicate ID Error

![Duplicate Error](screenshots/duplicate-error.png)

### Search

![Search](screenshots/search.png)

### Filter by Place

![Filter by Place](screenshots/filter-place.png)

### Filter by Category

![Filter by Category](screenshots/filter-category.png)

### Sort by Name A to Z

![Sort A-Z](screenshots/sort-a-z.png)

### Sort by Name Z to A

![Sort Z-A](screenshots/sort-z-a.png)

### Sort by Price

![Sort by Price](screenshots/sort-by-price.png)

### No Results

![No Results](screenshots/no-results.png)

### Remove Confirmation

![Delete](screenshots/delete.png)

### Mobile View

![Mobile](screenshots/mobile.png)

## By Sabir Chauhan
