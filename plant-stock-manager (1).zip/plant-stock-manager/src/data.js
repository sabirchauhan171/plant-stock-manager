export const categories = [
  "Flowering",
  "Succulent",
  "Herbs",
  "Foliage",
  "Fruit Plants",
  "Palms",
];

export const locations = ["Indoor", "Outdoor"];

export const initialPlants = [
  { id: 1, plantId: "PL-101", name: "Rose Bush", email: "rosefarm@greenroots.in", location: "Outdoor", price: 180, category: "Flowering" },
  { id: 2, plantId: "PL-102", name: "Aloe Vera", email: "supply@desertleaf.in", location: "Indoor", price: 120, category: "Succulent" },
  { id: 3, plantId: "PL-103", name: "Tulsi Holy Basil", email: "herbs@ayushgarden.in", location: "Outdoor", price: 60, category: "Herbs" },
  { id: 4, plantId: "PL-104", name: "Money Plant", email: "hello@urbanvine.in", location: "Indoor", price: 90, category: "Foliage" },
  { id: 5, plantId: "PL-105", name: "Mango Sapling", email: "orchard@kesarfruits.in", location: "Outdoor", price: 450, category: "Fruit Plants" },
  { id: 6, plantId: "PL-106", name: "Areca Palm", email: "palms@tropicnest.in", location: "Indoor", price: 380, category: "Palms" },
  { id: 7, plantId: "PL-107", name: "Jade Plant", email: "supply@desertleaf.in", location: "Indoor", price: 210, category: "Succulent" },
  { id: 8, plantId: "PL-108", name: "Hibiscus", email: "rosefarm@greenroots.in", location: "Outdoor", price: 150, category: "Flowering" },
  { id: 9, plantId: "PL-109", name: "Mint Pudina", email: "herbs@ayushgarden.in", location: "Outdoor", price: 45, category: "Herbs" },
  { id: 10, plantId: "PL-110", name: "Snake Plant", email: "hello@urbanvine.in", location: "Indoor", price: 260, category: "Foliage" },
  { id: 11, plantId: "PL-111", name: "Lemon Tree", email: "orchard@kesarfruits.in", location: "Outdoor", price: 320, category: "Fruit Plants" },
  { id: 12, plantId: "PL-112", name: "Ponytail Palm", email: "palms@tropicnest.in", location: "Indoor", price: 540, category: "Palms" },
  { id: 13, plantId: "PL-113", name: "Jasmine Mogra", email: "rosefarm@greenroots.in", location: "Outdoor", price: 140, category: "Flowering" },
  { id: 14, plantId: "PL-114", name: "Peace Lily", email: "hello@urbanvine.in", location: "Indoor", price: 290, category: "Foliage" },
];
