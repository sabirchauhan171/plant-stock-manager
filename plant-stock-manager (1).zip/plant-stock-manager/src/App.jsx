import { useMemo, useState } from "react";
import "./App.css";
import { categories, locations, initialPlants } from "./data";

const emptyForm = {
  plantId: "",
  name: "",
  email: "",
  location: "",
  price: "",
  category: "",
};

function App() {
  const [plants, setPlants] = useState(initialPlants);

  const [form, setForm] = useState(emptyForm);
  const [error, setError] = useState("");

  const [search, setSearch] = useState("");
  const [locationFilter, setLocationFilter] = useState("All");
  const [categoryFilter, setCategoryFilter] = useState("All");

  const [nameSort, setNameSort] = useState("default");
  const [priceSort, setPriceSort] = useState("default");

  const [deleteTarget, setDeleteTarget] = useState(null);

  const updateField = (key, value) => {
    setForm((prev) => ({ ...prev, [key]: value }));
    if (error) setError("");
  };

  const handleSubmit = (e) => {
    e.preventDefault();

    const { plantId, name, email, location, price, category } = form;

    if (!plantId || !name || !email || !location || !price || !category) {
      setError("Please fill all fields.");
      return;
    }

    const duplicate = plants.some(
      (p) => p.plantId.toLowerCase() === plantId.trim().toLowerCase()
    );

    if (duplicate) {
      setError("A plant with this Plant ID already exists.");
      return;
    }

    const newPlant = {
      id: Date.now(),
      plantId: plantId.trim(),
      name: name.trim(),
      email: email.trim(),
      location,
      price: Number(price),
      category,
    };

    setPlants((prev) => [...prev, newPlant]);
    setForm(emptyForm);
    setError("");
  };

  const confirmDelete = () => {
    if (!deleteTarget) return;
    setPlants((prev) => prev.filter((p) => p.id !== deleteTarget.id));
    setDeleteTarget(null);
  };

  const resetFilters = () => {
    setSearch("");
    setLocationFilter("All");
    setCategoryFilter("All");
    setNameSort("default");
    setPriceSort("default");
  };

  const visiblePlants = useMemo(() => {
    const q = search.toLowerCase().trim();

    const result = plants.filter((p) => {
      const matchesSearch =
        !q ||
        p.plantId.toLowerCase().includes(q) ||
        p.name.toLowerCase().includes(q) ||
        p.email.toLowerCase().includes(q) ||
        p.location.toLowerCase().includes(q) ||
        String(p.price).includes(q) ||
        p.category.toLowerCase().includes(q);

      const matchesLocation =
        locationFilter === "All" || p.location === locationFilter;

      const matchesCategory =
        categoryFilter === "All" || p.category === categoryFilter;

      return matchesSearch && matchesLocation && matchesCategory;
    });

    // Name is the primary sort, price is the secondary sort.
    result.sort((a, b) => {
      if (nameSort !== "default") {
        const x = a.name.toLowerCase();
        const y = b.name.toLowerCase();
        if (x < y) return nameSort === "az" ? -1 : 1;
        if (x > y) return nameSort === "az" ? 1 : -1;
      }
      if (priceSort !== "default") {
        if (a.price < b.price) return priceSort === "low" ? -1 : 1;
        if (a.price > b.price) return priceSort === "low" ? 1 : -1;
      }
      return 0;
    });

    return result;
  }, [plants, search, locationFilter, categoryFilter, nameSort, priceSort]);

  const hasActiveFilters =
    search.trim() !== "" ||
    locationFilter !== "All" ||
    categoryFilter !== "All" ||
    nameSort !== "default" ||
    priceSort !== "default";

  const stockValue = plants.reduce((sum, p) => sum + p.price, 0);

  return (
    <div className="shell">
      {/* ---------- Left panel: add plant ---------- */}
      <aside className="side">
        <div className="brand">
          <span className="brand-leaf">🌿</span>
          <div>
            <h1>Green Corner</h1>
            <p>Nursery stock manager</p>
          </div>
        </div>

        <form className="add-form" onSubmit={handleSubmit} noValidate>
          <h2>Add a new plant</h2>

          <label>
            Plant ID
            <input
              type="text"
              placeholder="PL-115"
              value={form.plantId}
              onChange={(e) => updateField("plantId", e.target.value)}
            />
          </label>

          <label>
            Plant name
            <input
              type="text"
              placeholder="e.g. Marigold"
              value={form.name}
              onChange={(e) => updateField("name", e.target.value)}
            />
          </label>

          <label>
            Supplier email
            <input
              type="email"
              placeholder="supplier@nursery.in"
              value={form.email}
              onChange={(e) => updateField("email", e.target.value)}
            />
          </label>

          <div className="two-col">
            <label>
              Place
              <select
                value={form.location}
                onChange={(e) => updateField("location", e.target.value)}
              >
                <option value="">Select</option>
                {locations.map((l) => (
                  <option key={l} value={l}>
                    {l}
                  </option>
                ))}
              </select>
            </label>

            <label>
              Price (₹)
              <input
                type="number"
                min="1"
                placeholder="199"
                value={form.price}
                onChange={(e) => updateField("price", e.target.value)}
              />
            </label>
          </div>

          <label>
            Category
            <select
              value={form.category}
              onChange={(e) => updateField("category", e.target.value)}
            >
              <option value="">Select category</option>
              {categories.map((c) => (
                <option key={c} value={c}>
                  {c}
                </option>
              ))}
            </select>
          </label>

          {error && <div className="form-error">{error}</div>}

          <button type="submit" className="btn-add">
            Add to stock
          </button>
        </form>
      </aside>

      {/* ---------- Main area ---------- */}
      <main className="main">
        <section className="stats">
          <div className="stat">
            <span className="stat-num">{plants.length}</span>
            <span className="stat-label">Plants in stock</span>
          </div>
          <div className="stat">
            <span className="stat-num">
              ₹{stockValue.toLocaleString("en-IN")}
            </span>
            <span className="stat-label">Total list value</span>
          </div>
          <div className="stat">
            <span className="stat-num">
              {new Set(plants.map((p) => p.category)).size}
            </span>
            <span className="stat-label">Categories</span>
          </div>
        </section>

        <section className="toolbar">
          <div className="search">
            <span aria-hidden="true">🔍</span>
            <input
              type="text"
              placeholder="Search by ID, name, supplier, category, price..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
            />
          </div>

          <div className="selects">
            <label>
              Place
              <select
                value={locationFilter}
                onChange={(e) => setLocationFilter(e.target.value)}
              >
                <option value="All">All</option>
                {locations.map((l) => (
                  <option key={l} value={l}>
                    {l}
                  </option>
                ))}
              </select>
            </label>

            <label>
              Category
              <select
                value={categoryFilter}
                onChange={(e) => setCategoryFilter(e.target.value)}
              >
                <option value="All">All categories</option>
                {categories.map((c) => (
                  <option key={c} value={c}>
                    {c}
                  </option>
                ))}
              </select>
            </label>

            <label>
              Name
              <select
                value={nameSort}
                onChange={(e) => setNameSort(e.target.value)}
              >
                <option value="default">Default</option>
                <option value="az">A to Z</option>
                <option value="za">Z to A</option>
              </select>
            </label>

            <label>
              Price
              <select
                value={priceSort}
                onChange={(e) => setPriceSort(e.target.value)}
              >
                <option value="default">Default</option>
                <option value="low">Low to High</option>
                <option value="high">High to Low</option>
              </select>
            </label>

            <button
              type="button"
              className="btn-reset"
              onClick={resetFilters}
              disabled={!hasActiveFilters}
            >
              Clear all
            </button>
          </div>
        </section>

        {hasActiveFilters && (
          <div className="chips">
            <span className="chips-title">Applied:</span>
            {search.trim() && <span className="chip">“{search.trim()}”</span>}
            {locationFilter !== "All" && (
              <span className="chip">{locationFilter}</span>
            )}
            {categoryFilter !== "All" && (
              <span className="chip">{categoryFilter}</span>
            )}
            {nameSort === "az" && <span className="chip">Name A to Z</span>}
            {nameSort === "za" && <span className="chip">Name Z to A</span>}
            {priceSort === "low" && (
              <span className="chip">Price low to high</span>
            )}
            {priceSort === "high" && (
              <span className="chip">Price high to low</span>
            )}
          </div>
        )}

        <div className="list-head">
          <h2>Plant catalogue</h2>
          <span>
            {visiblePlants.length} of {plants.length} plants
          </span>
        </div>

        {plants.length === 0 ? (
          <div className="empty">
            <div className="empty-icon">🪴</div>
            <h3>Your nursery is empty</h3>
            <p>Add your first plant from the panel on the left.</p>
          </div>
        ) : visiblePlants.length === 0 ? (
          <div className="empty">
            <div className="empty-icon">🔎</div>
            <h3>No plants match</h3>
            <p>Try a different search or clear the filters.</p>
            <button type="button" className="btn-reset" onClick={resetFilters}>
              Clear all
            </button>
          </div>
        ) : (
          <div className="grid">
            {visiblePlants.map((p) => (
              <article className="card" key={p.id}>
                <div className="card-top">
                  <span className="pid">{p.plantId}</span>
                  <span className={`place ${p.location.toLowerCase()}`}>
                    {p.location}
                  </span>
                </div>

                <h3>{p.name}</h3>
                <span className="cat">{p.category}</span>

                <p className="supplier">{p.email}</p>

                <div className="card-bottom">
                  <strong className="price">₹{p.price}</strong>
                  <button
                    type="button"
                    className="btn-remove"
                    onClick={() => setDeleteTarget(p)}
                  >
                    Remove
                  </button>
                </div>
              </article>
            ))}
          </div>
        )}

        <p className="hint">
          Sorting rule: name is applied first, price is used when names are the
          same.
        </p>
      </main>

      {/* ---------- Delete confirmation ---------- */}
      {deleteTarget && (
        <div className="overlay" onClick={() => setDeleteTarget(null)}>
          <div className="modal" onClick={(e) => e.stopPropagation()}>
            <h3>Remove this plant?</h3>
            <p>
              <strong>{deleteTarget.name}</strong> ({deleteTarget.plantId}) will
              be removed from the stock list.
            </p>
            <div className="modal-actions">
              <button
                type="button"
                className="btn-reset"
                onClick={() => setDeleteTarget(null)}
              >
                Keep it
              </button>
              <button
                type="button"
                className="btn-danger"
                onClick={confirmDelete}
              >
                Yes, remove
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

export default App;
